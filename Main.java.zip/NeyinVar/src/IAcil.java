public interface IAcil {

    public void giris();
    public void cikis();
}
